-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2020 at 08:27 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `raman`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `productid` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `productid`, `user`, `created_at`) VALUES
(28, '10', '2', '2020-12-09 18:52:32'),
(29, '11', '2', '2020-12-09 18:52:33');

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `id` int(11) NOT NULL,
  `oid` varchar(50) NOT NULL,
  `ptitle` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`id`, `oid`, `ptitle`, `price`) VALUES
(1, '1', 'Casual Style ', '500'),
(2, '2', 'Casual Style ', '500');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user`, `address`, `created_at`) VALUES
(1, '2', 'ttttrtrtret', '2020-12-09 18:40:05'),
(2, '2', 'ttttrtrtret', '2020-12-09 18:44:09');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `img` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `price`, `img`, `category`, `created_at`) VALUES
(1, '16GB DDR4 3600MHz RAM CORSAIR VENGEANCE RGB PRO SL', '3,990', 'RAM1.jpg', 'Women', '2020-12-09 01:40:06'),
(2, '16GB DDR4 3600MHz RAM KINGSTON FURY BEAST DDR4', '2,890', 'RAM2.jpeg', 'Women', '2020-12-09 01:40:06'),
(3, '16GB DDR4 3600MHz RAM KINGSTON FURY BEAST DDR4 RGB', '2,990', 'RAM3.jpg', 'Women', '2020-12-09 02:29:46'),
(4, '16GB DDR4 3600MHz RAM THERMALTAKE TOUGHRAM', '5,590', 'RAM4.jpg', 'Women', '2020-12-09 02:46:10'),
(5, '16GB DDR4 3600MHz RAM THERMALTAKE TURQUOISE', '5,590', 'RAM5.jpg', 'Women', '2020-12-09 02:49:43'),
(6, '16GB DDR4 3600MHz RAM G.SKILL TRIDENT Z RGB', '3,390', 'RAM6.jpg', 'Women', '2020-12-09 02:49:43'),
(7, '64GB DDR4 3600MHz RAM CORSAIR VENGEANCE RGB', '15,900', 'RAM7.jpg', 'Women', '2020-12-09 02:52:06'),
(8, '32GB DDR4 3600MHz RAM CORSAIR VENGEANCE RT', '6,590', 'RAM8.jpg', 'Women', '2020-12-09 02:53:40'),
(9, 'ASUS ROG STRIX GEFORCE RTX 3080 12GB GDDR6X OC EVA EDITION ', '54,500', 'GPU1.jpg', 'Mens', '2020-12-09 02:56:29'),
(10, 'MSI GEFORCE RTX 3070 VENTUS 3X PLUS 8G OC LHR - 8GB GDDR6', '21,500', 'GPU2.jpg', 'Mens', '2020-12-09 02:58:11'),
(11, 'ASUS TUF GAMING GEFORCE RTX 3050 OC EDITION 8GB GDDR6', '12,900', 'GPU3.jpg', 'Mens', '2020-12-09 03:00:21'),
(12, 'MSI GEFORCE RTX 3090 TI SUPRIM X 24G - 24GB GDDR6X', '52,900', 'GPU4.jpg', 'Mens', '2020-12-09 03:01:29'),
(13, 'INNO3D GEFORCE RTX 3080 X3 LHR - 10GB GDDR6X', '26,900', 'GPU5.jpg', 'Mens', '2020-12-09 03:03:33'),
(14, 'GIGABYTE GEFORCE RTX 3060 TI GAMING 8G (REV. 2.0) - 8GB GDDR6', '17,900', 'GPU6.jpg', 'Mens', '2020-12-09 03:05:17'),
(15, 'MANLI GEFORCE RTX 3070 TI - 8GB GDDR6X', '23,200', 'GPU7.jpg', 'Mens', '2020-12-09 03:07:05'),
(16, 'MANLI GEFORCE RTX 3050 GALLARDO - 8GB GDDR6', '10,700', 'GPU8.jpg', 'Mens', '2020-12-09 03:08:13');


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`, `created_at`) VALUES
(2, 'Rman', 'raman@gmail.com', '7986568931', 'e10adc3949ba59abbe56e057f20f883e', '2020-12-09 06:10:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
